code = ""
name = ['body_cate', 'hat_cate', 'hair_cate', 'clothing_cate', 'neck_cate']
for names in name:
    code += f"""
    .{names} {{
  appearance: button;
  background-color: #1899D6;
  border: solid transparent;
  border-radius: 16px;
  border-width: 0 0 4px;
  box-sizing: border-box;
  font-family: "Outfit";
  color: #FFFFFF;
  cursor: pointer;
  display: inline-block;
  font-size: 27px;
  font-weight: 700;
  letter-spacing: .8px;
  line-height: 20px;
  margin: 0;
  outline: none;
  overflow: visible;
  padding: 13px 16px;
  text-align: center;
  text-transform: uppercase;
  touch-action: manipulation;
  transform: translateZ(0);
  transition: filter .2s;
  user-select: none;
  -webkit-user-select: none;
  vertical-align: middle;
  white-space: nowrap;
  width: 100%;
}}

.{names}:after {{
  background-clip: padding-box;
  background-color: #1CB0F6;
  border: solid transparent;
  border-radius: 16px;
  border-width: 0 0 4px;
  font-family: "Outfit";
  bottom: -4px;
  content: "";
  left: 0;
  position: absolute;
  right: 0;
  top: 0;
  z-index: -1;
}}

.{names}:main,
.{names}:focus {{
  user-select: auto;
}}

.{names}:hover:not(:disabled) {{
  filter: brightness(1.1);
  -webkit-filter: brightness(1.1);
}}

.{names}:disabled {{
  cursor: auto;
}}

.{names}:active {{
  border-width: 4px 0 0;
  background: none;
}}
    """
print(code)
